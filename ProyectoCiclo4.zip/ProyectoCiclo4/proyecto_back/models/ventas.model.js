const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const VentasSchema = mongoose.Schema({
    venta_id: {type: String, required: true, max: 60},
    producto_id: {type: String, required: true, max: 60},
    cliente_id: {type: String, required: true, max: 60},
    fecha: {type: String, required: true, max: 60},
    cantidad: {type: Number, required: true, max: 15000000000},
    precio: {type: Number, required: true, max: 15000000000},
    precio_total: {type: Number, required: true, max: 15000000000},
});

module.exports = mongoose.model("ventas", VentasSchema);