const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const AromasSchema = mongoose.Schema({
    producto_id: {type: String, required: true, max: 60},
    aroma: {type: String, required: true, max: 40},
    descripcion: {type: String, required: true, max: 4000},
    precio: {type: Number, required: true, max: 15000000000},
    foto: {type: String, required: false, max: 70}, 
    tipo: {type: String, required: false, max: 70}, 
});

module.exports = mongoose.model("aromas", AromasSchema);