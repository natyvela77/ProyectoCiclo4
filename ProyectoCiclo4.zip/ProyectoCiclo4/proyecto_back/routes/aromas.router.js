const express = require("express");
const router = express.Router();
const aromasController = require("../controllers/aromas.controller")

router.post("/", aromasController.create)
router.get("/", aromasController.find)  
router.get("/:id", aromasController.findOne)
router.put("/:id", aromasController.update)
router.delete("/:id", aromasController.remove)
module.exports =router