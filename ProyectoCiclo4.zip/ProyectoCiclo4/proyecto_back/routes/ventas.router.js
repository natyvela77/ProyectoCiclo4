const express = require("express");
const router = express.Router();
const ventasController = require("../controllers/ventas.controller")

router.post("/", ventasController.create)
router.get("/", ventasController.find)  
router.get("/:id", ventasController.findOne)
router.put("/:id", ventasController.update)
router.delete("/:id", ventasController.remove)
module.exports =router