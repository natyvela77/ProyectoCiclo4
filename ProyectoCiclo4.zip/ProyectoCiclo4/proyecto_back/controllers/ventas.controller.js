const Venta = require("../models/ventas.model")
let response = {
    msg:"",
    exito:false,
}

exports.create = function(req,res){
    let venta = new Venta({
        venta_id:req.body.venta_id,
        producto_id: req.body.producto_id,
        cliente_id: req.body.cliente_id,
        fecha: req.body.fecha,
        cantidad: req.body.cantidad,
        precio: req.body.precio,
        precio_total: req.body.precio_total,
    
    })
    venta.save(function(err){
        if(err){
            console.error(err),
            response.exito =false,
            response.msg ="Error al guardar la venta"
            res.json(response)
            return;
        }
        response.exito = true,
        response.msg = "La venta se guardo correctamente"
        res.json(response)
    }
    )
}

exports.find = function(req, res) { 
    Venta.find(function(err,ventas){
        res.json(ventas)
    })
}
exports.findOne = function(req, res) { 
    Venta.findOne({_id: req.params.id}, function(err,venta){
        res.json(venta)
    })
}

exports.update = function(req,res){
    let venta=({
        venta_id:req.body.venta_id,
        producto_id: req.body.producto_id,
        cliente_id: req.body.cliente_id,
        fecha: req.body.fecha,
        cantidad: req.body.cantidad,
        precio: req.body.precio,
        precio_total: req.body.precio_total,
        })
   Venta.findByIdAndUpdate(req.params.id,{$set: venta},function(err){
        if(err){
            console.error(err),
            response.exito =false,
            response.msg ="Error al guardar al venta"
            res.json(response)
            return;
        }
        response.exito = true,
        response.msg = "El venta se guardo correctamente"
        res.json(response)
    }
    )
}

exports.remove = function(req,res){
   Venta.findByIdAndRemove({_id: req.params.id},function(err){
        if(err){
            console.error(err),
            response.exito =false,
            response.msg ="Error al eliminar al venta"
            res.json(response)
            return;
        }
        response.exito = true,
        response.msg = "El venta se elimino correctamente"
        res.json(response)
    }
    )
}
