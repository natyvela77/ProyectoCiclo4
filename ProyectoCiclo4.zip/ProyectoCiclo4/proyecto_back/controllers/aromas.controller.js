const Aroma = require("../models/aromas.model")
let response = {
    msg:"",
    exito:false,
}

exports.create = function(req,res){
    let aroma = new Aroma({
        producto_id: req.body.producto_id,
        aroma: req.body.aroma,
        descripcion: req.body.descripcion,
        precio: req.body.precio,
        foto: req.body.foto,
        tipo:req.body.tipo,
    })
    aroma.save(function(err){
        if(err){
            console.error(err),
            response.exito =false,
            response.msg ="Error al guardar al aroma"
            res.json(response)
            return;
        }
        response.exito = true,
        response.msg = "El aroma se guardo correctamente"
        res.json(response)
    }
    )
}

exports.find = function(req, res) { 
    Aroma.find(function(err,aromas){
        res.json(aromas)
    })
}
exports.findOne = function(req, res) { 
    Aroma.findOne({_id: req.params.id}, function(err,aroma){
        res.json(aroma)
    })
}

exports.update = function(req,res){
    let aroma=({
        producto_id: req.body.producto_id,
        aroma: req.body.aroma,
        descripcion: req.body.descripcion,
        precio: req.body.precio,
        foto: req.body.foto,
        tipo: req.body.tipo,
    })
   Aroma.findByIdAndUpdate(req.params.id,{$set: aroma},function(err){
        if(err){
            console.error(err),
            response.exito =false,
            response.msg ="Error al guardar al aroma"
            res.json(response)
            return;
        }
        response.exito = true,
        response.msg = "El aroma se guardo correctamente"
        res.json(response)
    }
    )
}

exports.remove = function(req,res){
   Aroma.findByIdAndRemove({_id: req.params.id},function(err){
        if(err){
            console.error(err),
            response.exito =false,
            response.msg ="Error al eliminar al aroma"
            res.json(response)
            return;
        }
        response.exito = true,
        response.msg = "El aroma se elimino correctamente"
        res.json(response)
    }
    )
}
