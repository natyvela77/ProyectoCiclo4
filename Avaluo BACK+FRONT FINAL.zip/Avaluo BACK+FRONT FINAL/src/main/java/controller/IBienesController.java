package controller;

import java.util.Map;

public interface IBienesController {
    
    public String registerpropiedad(String idpropiedad, String username, String area, String ciudad, String estrato, String antiguedad, String tipovivienda, String habitaciones, String banos, String centrocomercial, String parque, String valorarriendo, String valorventa, String valormetro);
}
