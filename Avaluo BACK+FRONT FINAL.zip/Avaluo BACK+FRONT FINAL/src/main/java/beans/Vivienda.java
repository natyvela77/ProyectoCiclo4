package beans;

public class Vivienda {
    
}
